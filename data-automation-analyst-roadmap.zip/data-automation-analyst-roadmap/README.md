# 🚀 Data + Automation Analyst Roadmap  

This repository tracks my **4-month journey** to becoming a **Data + Automation Analyst**.  
The goal: build **job-ready skills** in Data Analytics (SQL, Excel, Tableau/Power BI, Python) and **Automation** (Python scripts + n8n) — and finish with a strong **portfolio** for MNC roles.  

---

## 📌 Goals  
- ✅ Master SQL, Excel, Python, Tableau/Power BI  
- ✅ Learn automation with Python + n8n  
- ✅ Build 1 project every 2 weeks → upload here  
- ✅ Capstone project + polished portfolio  

---

## 📂 Repository Structure  

- **/roadmap** → Timeline & weekly goals  
- **/projects** → Bi-weekly projects with README + code/data  
- **/portfolio** → Final polished work (resume, dashboards, case studies)  
- **/notes** → Quick notes, cheatsheets, snippets  

---

## 🛠️ Learning Resources  

- **Python** → [BroCode YouTube](https://youtu.be/XKHEtdqhLK8)  
- **SQL** → [W3Schools SQL](https://www.w3schools.com/sql/) | [LeetCode SQL](https://leetcode.com/problemset/database/)  
- **Excel** → [Excel Exposure](https://excelexposure.com/)  
- **Power BI** → [Microsoft Learn](https://learn.microsoft.com/en-us/training/powerplatform/power-bi/)  
- **Tableau** → [Free Training Videos](https://www.tableau.com/learn/training/20203)  
- **Automation (n8n)** → [n8n Docs](https://docs.n8n.io/)  

---

## 📅 Timeline  

- **Week 1–2** → Python fundamentals + Project 1 (SQL Analysis)  
- **Week 3–4** → SQL deep dive + Project 2 (Excel Dashboard)  
- **Week 5–6** → Tableau/Power BI + Project 3  
- **Week 7–8** → Python for automation + Project 4  
- **Week 9–12** → Advanced automation + Capstone project  

---

## 🚀 Portfolio (in progress)  
- Projects → `/projects`  
- Dashboards → `/portfolio/dashboards`  
- Resume → `/portfolio/resume.pdf`  

---

## 🤝 Connect  
If you’re following a similar path, feel free to fork this repo and use the roadmap!
